package com.example.anarkisansathi

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class CropGuideActivity : AppCompatActivity() {
    lateinit var tts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crop_guide)

        val cropText = findViewById<TextView>(R.id.txtCropInfo)
        cropText.text = "अनार की खेती के लिए रेतीली-दोमट मिट्टी सर्वोत्तम होती है..."

        tts = TextToSpeech(this) {
            if (it == TextToSpeech.SUCCESS) {
                tts.language = Locale("hi", "IN")
                tts.speak(cropText.text.toString(), TextToSpeech.QUEUE_FLUSH, null, null)
            }
        }
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}